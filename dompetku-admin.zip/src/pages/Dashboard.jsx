import React from 'react';

function Dashboard() {
  return (
    <div className="p-4 text-xl font-semibold">
      Halaman Dashboard Admin Dompetku
    </div>
  );
}

export default Dashboard;